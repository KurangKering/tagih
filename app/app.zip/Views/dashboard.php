<?= $this->extend('top_layout') ?>



<?= $this->section('content') ?>

<!-- Content Header (Page header) -->
<div class="content-header">
  <!-- /.container -->
</div>
<!-- /.content-header -->

<!-- Main content -->
<div class="content">
  <!-- /.container -->
</div>
<!-- /.content -->

<?= $this->endSection() ?>